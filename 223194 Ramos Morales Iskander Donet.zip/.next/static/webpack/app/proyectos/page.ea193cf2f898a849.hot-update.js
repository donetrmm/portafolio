/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("app/proyectos/page",{

/***/ "(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Cimage-component.js&modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Csrc%5Ccomponents%5Ccss%5Ccard-description.css&modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Csrc%5Capp%5Cproyectos%5Cproyectos.css&server=false!":
/*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Cimage-component.js&modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Csrc%5Ccomponents%5Ccss%5Ccard-description.css&modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Csrc%5Capp%5Cproyectos%5Cproyectos.css&server=false! ***!
  \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ (function(__unused_webpack_module, __unused_webpack_exports, __webpack_require__) {

eval(__webpack_require__.ts("Promise.resolve(/*! import() eager */).then(__webpack_require__.t.bind(__webpack_require__, /*! ./node_modules/next/dist/client/image-component.js */ \"(app-pages-browser)/./node_modules/next/dist/client/image-component.js\", 23));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./src/components/css/card-description.css */ \"(app-pages-browser)/./src/components/css/card-description.css\"));\nPromise.resolve(/*! import() eager */).then(__webpack_require__.bind(__webpack_require__, /*! ./src/app/proyectos/proyectos.css */ \"(app-pages-browser)/./src/app/proyectos/proyectos.css\"))//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL25vZGVfbW9kdWxlcy9uZXh0L2Rpc3QvYnVpbGQvd2VicGFjay9sb2FkZXJzL25leHQtZmxpZ2h0LWNsaWVudC1lbnRyeS1sb2FkZXIuanM/bW9kdWxlcz1DJTNBJTVDd2FtcDY0JTVDd3d3JTVDcG9ydGFmb2xpbyU1Q25vZGVfbW9kdWxlcyU1Q25leHQlNUNkaXN0JTVDY2xpZW50JTVDaW1hZ2UtY29tcG9uZW50LmpzJm1vZHVsZXM9QyUzQSU1Q3dhbXA2NCU1Q3d3dyU1Q3BvcnRhZm9saW8lNUNzcmMlNUNjb21wb25lbnRzJTVDY3NzJTVDY2FyZC1kZXNjcmlwdGlvbi5jc3MmbW9kdWxlcz1DJTNBJTVDd2FtcDY0JTVDd3d3JTVDcG9ydGFmb2xpbyU1Q3NyYyU1Q2FwcCU1Q3Byb3llY3RvcyU1Q3Byb3llY3Rvcy5jc3Mmc2VydmVyPWZhbHNlISIsIm1hcHBpbmdzIjoiQUFBQSxvT0FBc0g7QUFDdEgsNE1BQTRHO0FBQzVHIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8/YmFjNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIkM6XFxcXHdhbXA2NFxcXFx3d3dcXFxccG9ydGFmb2xpb1xcXFxub2RlX21vZHVsZXNcXFxcbmV4dFxcXFxkaXN0XFxcXGNsaWVudFxcXFxpbWFnZS1jb21wb25lbnQuanNcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIkM6XFxcXHdhbXA2NFxcXFx3d3dcXFxccG9ydGFmb2xpb1xcXFxzcmNcXFxcY29tcG9uZW50c1xcXFxjc3NcXFxcY2FyZC1kZXNjcmlwdGlvbi5jc3NcIik7XG5pbXBvcnQoLyogd2VicGFja01vZGU6IFwiZWFnZXJcIiAqLyBcIkM6XFxcXHdhbXA2NFxcXFx3d3dcXFxccG9ydGFmb2xpb1xcXFxzcmNcXFxcYXBwXFxcXHByb3llY3Rvc1xcXFxwcm95ZWN0b3MuY3NzXCIpIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(app-pages-browser)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Cnode_modules%5Cnext%5Cdist%5Cclient%5Cimage-component.js&modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Csrc%5Ccomponents%5Ccss%5Ccard-description.css&modules=C%3A%5Cwamp64%5Cwww%5Cportafolio%5Csrc%5Capp%5Cproyectos%5Cproyectos.css&server=false!\n"));

/***/ }),

/***/ "(app-pages-browser)/./src/components/css/card-description.css":
/*!*************************************************!*\
  !*** ./src/components/css/card-description.css ***!
  \*************************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval(__webpack_require__.ts("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = (\"02e031f645e9\");\nif (true) { module.hot.accept() }\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwcC1wYWdlcy1icm93c2VyKS8uL3NyYy9jb21wb25lbnRzL2Nzcy9jYXJkLWRlc2NyaXB0aW9uLmNzcyIsIm1hcHBpbmdzIjoiO0FBQUEsK0RBQWUsY0FBYztBQUM3QixJQUFJLElBQVUsSUFBSSxpQkFBaUIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvY3NzL2NhcmQtZGVzY3JpcHRpb24uY3NzP2M1OGMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgXCIwMmUwMzFmNjQ1ZTlcIlxuaWYgKG1vZHVsZS5ob3QpIHsgbW9kdWxlLmhvdC5hY2NlcHQoKSB9XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(app-pages-browser)/./src/components/css/card-description.css\n"));

/***/ })

});